-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Mar 2023 pada 05.48
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pengaduan_masyarakat`
--

DELIMITER $$
--
-- Prosedur
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert petugas` (IN `id_ptgs` INT(11), IN `nama_ptgs` VARCHAR(35), IN `username_ptgs` VARCHAR(25), IN `pass_ptgs` VARCHAR(25), IN `telp_ptgs` VARCHAR(13), IN `level_ptgs` ENUM('admin','petugas'))  INSERT INTO petugas (id_petugas, nama_petugas, username, password, telp, level) VALUES (id_ptgs, nama_ptgs, username_ptgs, pass_ptgs, telp_ptgs, level_ptgs)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `data_pengaduan`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `data_pengaduan` (
`nik` char(11)
,`nama` varchar(35)
,`tgl_pengaduan` date
,`isi_laporan` text
);

-- --------------------------------------------------------

--
-- Struktur dari tabel `masyarakat`
--

CREATE TABLE `masyarakat` (
  `nik` char(11) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `telp` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `masyarakat`
--

INSERT INTO `masyarakat` (`nik`, `nama`, `username`, `password`, `telp`) VALUES
('32012178820', 'milda maylani', 'milda', '202cb962ac59075b964b07152d234b70', '082116085931'),
('32013567117', 'risma tri wahyuni', 'risma', '202cb962ac59075b964b07152d234b70', '08979835796'),
('32022122030', 'tyara laudya', 'tyara', '202cb962ac59075b964b07152d234b70', '081214461961'),
('32030125037', 'mara humaerotuz zahra', 'mara', '202cb962ac59075b964b07152d234b70', '08996295871'),
('32041717104', 'syifa fadilah', 'syifa', '202cb962ac59075b964b07152d234b70', '083820858369'),
('32082178880', 'ihsan ', 'ihsan', '202cb962ac59075b964b07152d234b70', '089796357573');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengaduan`
--

CREATE TABLE `pengaduan` (
  `id_pengaduan` int(11) NOT NULL,
  `tgl_pengaduan` date NOT NULL,
  `nik` char(11) NOT NULL,
  `isi_laporan` text NOT NULL,
  `foto` varchar(255) NOT NULL,
  `status` enum('proses','selesai') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengaduan`
--

INSERT INTO `pengaduan` (`id_pengaduan`, `tgl_pengaduan`, `nik`, `isi_laporan`, `foto`, `status`) VALUES
(1239, '2023-03-06', '32022122030', 'banyak sampah berserakan dan rumput liar di pinggir jalan menghalangi pejalan kaki', 'sampah.jpg', 'selesai'),
(1240, '2023-03-07', '32013567117', 'banyak sampah berserakan membuat selokan mampet', 'sampah-di-selokan-di-tanjung-priok_20180517_121018.jpg', 'selesai'),
(1241, '2023-03-07', '32030125037', 'banyak jalan berlubang berbahaya bagi pengendara kendaraan', 'jalan-rusak-ponorogo.jpeg', 'selesai'),
(1242, '2023-03-07', '32041717104', 'terjadi longsor di rt 05 rw 02', 'longsor.jpg', 'selesai'),
(1243, '2023-03-07', '32012178820', 'bak penampung air jebol', 'bak-penampungan-di-mekartijaya.jpg', 'selesai'),
(1244, '2023-03-16', '32030125037', 'Kebakaran ', 'bakaran.jpeg', 'selesai'),
(1245, '2023-03-16', '32082178880', 'Sampah menumpuk membuat bau sekitar tolong segera cari solusi', 'sampah sampah.jpg', 'selesai');

-- --------------------------------------------------------

--
-- Struktur dari tabel `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` int(11) NOT NULL,
  `nama_petugas` varchar(35) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `telp` varchar(13) NOT NULL,
  `level` enum('admin','petugas') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `nama_petugas`, `username`, `password`, `telp`, `level`) VALUES
(1, 'Rahma Khaerunisa', 'rahma', '202cb962ac59075b964b07152d234b70', '085795628376', 'admin'),
(2, 'Mila Nurfala', 'mila', '202cb962ac59075b964b07152d234b70', '085375437476', 'petugas'),
(3, 'Adibya Lofarsa', 'adib', '202cb962ac59075b964b07152d234b70', '084364753583', 'admin'),
(4, 'Malioboro Hartigan', 'malio', '202cb962ac59075b964b07152d234b70', '087314636531', 'petugas'),
(8, 'dea septiyani', 'dea', '202cb962ac59075b964b07152d234b70', '08977835769', 'petugas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tanggapan`
--

CREATE TABLE `tanggapan` (
  `id_tanggapan` int(11) NOT NULL,
  `id_pengaduan` int(11) NOT NULL,
  `tgl_tanggapan` date NOT NULL,
  `tanggapan` text NOT NULL,
  `id_petugas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tanggapan`
--

INSERT INTO `tanggapan` (`id_tanggapan`, `id_pengaduan`, `tgl_tanggapan`, `tanggapan`, `id_petugas`) VALUES
(5, 1239, '2023-03-06', 'akan di adakan kerja bakti 1 bulan sekali ', 8),
(6, 1240, '2023-03-07', 'secepatnya akan di adakan pembersihan selokan', 8),
(7, 1241, '2023-03-07', 'secepatnya di tangani agar warga nyaman dan aman', 2),
(8, 1242, '2023-03-07', 'akan di buatkan pos pengungsian untuk warga yang terdampak longsor', 1),
(9, 1243, '2023-03-07', 'siap di rundingkan dengan warga yang lain dan mencari solusi bersama', 4),
(10, 1244, '2023-03-16', 'akan segera memanggil pemadam', 2),
(11, 1245, '2023-03-16', 'segera di adakan kerja bakti dan imbauan dilarang membuang sampah disitu', 3);

-- --------------------------------------------------------

--
-- Struktur untuk view `data_pengaduan`
--
DROP TABLE IF EXISTS `data_pengaduan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `data_pengaduan`  AS   (select `masyarakat`.`nik` AS `nik`,`masyarakat`.`nama` AS `nama`,`pengaduan`.`tgl_pengaduan` AS `tgl_pengaduan`,`pengaduan`.`isi_laporan` AS `isi_laporan` from (`masyarakat` join `pengaduan`) where `masyarakat`.`nik` = `pengaduan`.`nik`)  ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `masyarakat`
--
ALTER TABLE `masyarakat`
  ADD PRIMARY KEY (`nik`);

--
-- Indeks untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD PRIMARY KEY (`id_pengaduan`),
  ADD KEY `nik` (`nik`);

--
-- Indeks untuk tabel `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indeks untuk tabel `tanggapan`
--
ALTER TABLE `tanggapan`
  ADD PRIMARY KEY (`id_tanggapan`),
  ADD KEY `id_pengaduan` (`id_pengaduan`),
  ADD KEY `id_petugas` (`id_petugas`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  MODIFY `id_pengaduan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1246;

--
-- AUTO_INCREMENT untuk tabel `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tanggapan`
--
ALTER TABLE `tanggapan`
  MODIFY `id_tanggapan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pengaduan`
--
ALTER TABLE `pengaduan`
  ADD CONSTRAINT `pengaduan_ibfk_1` FOREIGN KEY (`nik`) REFERENCES `masyarakat` (`nik`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tanggapan`
--
ALTER TABLE `tanggapan`
  ADD CONSTRAINT `tanggapan_ibfk_1` FOREIGN KEY (`id_pengaduan`) REFERENCES `pengaduan` (`id_pengaduan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tanggapan_ibfk_2` FOREIGN KEY (`id_petugas`) REFERENCES `petugas` (`id_petugas`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
